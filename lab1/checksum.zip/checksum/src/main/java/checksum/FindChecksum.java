package checksum;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.util.*;


public class FindChecksum {

	public static void main(String[] args)  throws Exception 
	{

		// The system configuration
		Configuration conf = new Configuration();
		// Get an instance of the Filesystem
		FileSystem fs = FileSystem.get(conf);
		String path_name = "/lab1/experiment2/bigdata";
		Path path = new Path(path_name);

		FSDataInputStream file = fs.open(path);

	    byte buffer[] = new byte[1000];
	    file.readFully(1000000000L,buffer);
	   
	    int checksum = buffer[0];
	    for (int i = 1; i < buffer.length; i++)
	    {
	      checksum ^= buffer[i];
	    }    

	    System.out.println("The Checksum obtained is : " + checksum);    
		file.close();
		fs.close();
	}
		// TODO Auto-generated method stub

	

}
